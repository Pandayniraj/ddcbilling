<?php

return [

    'password_changed'              => [
        'subject' => 'Password change notification.',
    ],
    'email_validation'              => [
        'subject' => 'Email validation.',
    ],

];
