<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete lead note',
        'body'    => 'Are you sure that you want to delete lead note ID :id with the note ":name"? This operation is irreversible.',
    ],

];
