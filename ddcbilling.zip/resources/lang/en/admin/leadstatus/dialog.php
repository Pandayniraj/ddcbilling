<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete leadstatus',
        'body'    => 'Are you sure that you want to delete leadstatus ID :id with the name ":name"? This operation is irreversible.',
    ],

];
