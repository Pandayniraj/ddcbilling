<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete lead file',
        'body'    => 'Are you sure that you want to delete lead file ID :id with the name ":name"? This operation is irreversible.',
    ],

];
