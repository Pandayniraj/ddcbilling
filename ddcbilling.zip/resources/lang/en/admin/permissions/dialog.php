<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete permission',
        'body'    => 'Are you sure that you want to delete permission ID :id with the name ":name"? This operation is irreversible.',
    ],

];
