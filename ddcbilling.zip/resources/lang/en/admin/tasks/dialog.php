<?php

return [

    'delete-confirm'              => [
        'title'   => 'Delete task',
        'body'    => 'Are you sure that you want to delete task ID :id with the name ":name"? This operation is irreversible.',
    ],

];
