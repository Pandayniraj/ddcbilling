<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IrdDetail extends Model
{
    use HasFactory;   
    protected $table = 'ird_detail';
    protected $guarded = [];
}
