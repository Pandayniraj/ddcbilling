<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Invoiceprint extends Model
{
    //
    protected $table = 'bill_print_invoice';
}
