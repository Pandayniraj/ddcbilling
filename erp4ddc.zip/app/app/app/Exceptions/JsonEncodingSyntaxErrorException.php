<?php

namespace App\Exceptions;

/**
 * @license GPLv3
 * @author Sebastien Routier (sroutier@gmail.com)
 */
class JsonEncodingSyntaxErrorException extends \Exception
{
}
